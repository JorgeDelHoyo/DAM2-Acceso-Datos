package util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Clase de utilidad para gestionar el EntityManagerFactory.
 *
 * - Debe existir UNA sola instancia de EntityManagerFactory por aplicación
 * - Cada operación creará su propio EntityManager
 */
public class JPAUtil {

    /**
     * EntityManagerFactory compartido
     */
    private static final EntityManagerFactory emf = null; // ← sustituir
    /*
         * TODO 1:
         *  - Inicializa el EntityManagerFactory usando Persistence.createEntityManagerFactory(...)
         *  - El nombre debe coincidir con el persistence-unit del persistence.xml
    */

    /**
     * Devuelve un EntityManager nuevo
     */
    public static EntityManager getEntityManager() {
        /*
         * TODO 2:
         *  - Devuelve un EntityManager usando el EntityManagerFactory
         */
        return null; // ← sustituir
    }

    /**
     * Cierra correctamente el EntityManagerFactory
     */
    public static void shutdown() {
        /*
         * TODO 3:
         *  - Cierra el EntityManagerFactory si está abierto
         *  - Este método se llamará al final del main cuando el programa ha terminado
         */
    }
}
